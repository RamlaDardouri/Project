package com.ramla.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


import com.ramla.project.entities.Labo;

import com.ramla.project.repo.LaboRepository;



@Service
public class LaboServiceImp implements LaboService{
	
	@Autowired
	LaboRepository laboRepository;

	@Override
	public Labo saveLabo(Labo l) {
	return laboRepository.save(l);
	}
	@Override
	public Labo updateLabo(Labo l) {
	return laboRepository.save(l);
	}
	@Override
	public void deleteLabo( Labo l) {
	laboRepository.delete(l);
	}
	 @Override
	public void deleteLaboById(Long id) {
	laboRepository.deleteById(id);
	}
	@Override
	public Labo getLabo(Long id) {
	return laboRepository.findById(id).get();
	}
	@Override
	public List<Labo> getAllLabos() {
	return laboRepository.findAll();
	}

	@Override
	public Page<Labo> getAllLabosParPage(int page, int size) {
	return laboRepository.findAll(PageRequest.of(page, size));
	}
	
}
