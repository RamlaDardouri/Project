package com.ramla.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ramla.project.entities.Formateur;


public interface FormateurRepository extends JpaRepository<Formateur, Long> {

}
