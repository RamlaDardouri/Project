package com.ramla.project;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.ramla.project.entities.Formateur;
import com.ramla.project.entities.Labo;

import com.ramla.project.repo.LaboRepository;
import com.ramla.project.service.LaboService;

@SpringBootTest
class ProjectApplicationTests {
@Autowired
private LaboRepository laboRepository;
private LaboService laboService;


@Test
public void testCreateLabo() {
Labo l  = new Labo(12,"xx","rr",new Date());
laboRepository.save(l);
}

@Test
public void testFindLabo()
{
Labo l = laboRepository.findById(1L).get();
System.out.println(l);
}
@Test
public void testUpdateLabo()
{
Labo l = laboRepository.findById(1L).get();
l.setType("kkk");
laboRepository.save(l);
}
@Test
public void testDeleteLabo()
{
laboRepository.deleteById(1L);;
}

@Test
public void testListerTousLabos()
{
List<Labo> l = laboRepository.findAll();
for (Labo l1 : l)
{
System.out.println(l1);
}
}


@Test
public void testFindByNbrContains()
{
Page<Labo> l = laboService.getAllLabosParPage(0,2);
System.out.println(l.getSize());
System.out.println(l.getTotalElements());
System.out.println(l.getTotalPages());
l.getContent().forEach(l1 -> {System.out.println(l1.toString());
 });

}



}