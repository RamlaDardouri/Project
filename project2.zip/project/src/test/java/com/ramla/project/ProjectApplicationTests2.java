package com.ramla.project;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.ramla.project.entities.Formateur;

import com.ramla.project.repo.FormateurRepository;
import com.ramla.project.service.FormateurService;


@SpringBootTest
class ProjectApplicationTests2 {
	
	@Autowired
	
	private FormateurRepository formateurRepository;

	private FormateurService formateurService;
	@Test
	public void testCreateFormateur() {
	Formateur f  = new Formateur("ramla",1771,"rddr",new Date());
	formateurRepository.save(f);
	}

	@Test
	public void testFindFormateur()
	{
	Formateur f = formateurRepository.findById(1L).get();
	System.out.println(f);
	}
	@Test
	public void testUpdateFormateur()
	{
	Formateur f = formateurRepository.findById(1L).get();
	f.setType("kkk");
	formateurRepository.save(f);
	}
	@Test
	public void testDeleteFormateur()
	{
	formateurRepository.deleteById(1L);
	}

	@Test
	public void testListerTousFormateurs()
	{
	List<Formateur> f = formateurRepository.findAll();
	for (Formateur f1 : f)
	{
	System.out.println(f1);
	}

	}


	@Test
	public void testFindByNomContains()
	{
	Page<Formateur> f = formateurService.getAllFormateursParPage(0,2);
	System.out.println(f.getSize());
	System.out.println(f.getTotalElements());
	System.out.println(f.getTotalPages());
	f.getContent().forEach(f1 -> {System.out.println(f1.toString());
	 });

	}




}