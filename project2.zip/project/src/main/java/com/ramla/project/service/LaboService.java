package com.ramla.project.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ramla.project.entities.Labo;

public interface LaboService {
	
	Labo saveLabo(Labo l);
	Labo updateLabo(Labo l);
	void deleteLabo(Labo l);
	 void deleteLaboById(Long id);
	Labo getLabo(Long id);
	List<Labo> getAllLabos();
	

	
	Page<Labo> getAllLabosParPage(int page, int size);

}
