package com.ramla.project.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ramla.project.entities.Formateur;


public interface FormateurService {
	Formateur saveFormateur(Formateur f);
	Formateur updateFormateur(Formateur f);
	void deleteFormateur(Formateur f);
	 void deleteFormateurById(Long id);
	Formateur getFormateur(Long id);
	List<Formateur> getAllFormateurs();
	
	
	Page<Formateur> getAllFormateursParPage(int page, int size);
	
}
