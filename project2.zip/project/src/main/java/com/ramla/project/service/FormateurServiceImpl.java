package com.ramla.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ramla.project.entities.Formateur;

import com.ramla.project.repo.FormateurRepository;

@Service
public class FormateurServiceImpl implements FormateurService {

	@Autowired
	
	FormateurRepository formateurRepository;
	
	@Override
	public Formateur saveFormateur(Formateur f) {
	return formateurRepository.save(f);
	}
	@Override
	public Formateur updateFormateur(Formateur f) {
	return formateurRepository.save(f);
	}
	@Override
	public void deleteFormateur(Formateur f) {
		formateurRepository.delete(f);
	}
	 @Override
	public void deleteFormateurById(Long id) {
		 formateurRepository.deleteById(id);
	}
	@Override
	public Formateur getFormateur(Long id) {
	return formateurRepository.findById(id).get();
	}
	@Override
	public List<Formateur> getAllFormateurs() {
	return formateurRepository.findAll();
	}
	
	@Override
	public Page<Formateur> getAllFormateursParPage(int page, int size) {
	return formateurRepository.findAll(PageRequest.of(page, size));
	}

}
