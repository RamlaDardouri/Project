package com.ramla.project.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ramla.project.entities.Formateur;
import com.ramla.project.entities.Labo;
import com.ramla.project.service.FormateurService;


@Controller
public class FormateurController {

@Autowired
FormateurService formateurService;

@RequestMapping("/CreateF")
public String CreateF()
{
return "createFormateur";
}


@RequestMapping("/saveFormateur")
public String saveFormateur(@ModelAttribute("formateur") Formateur formateur,
@RequestParam("date") String date,
ModelMap modelMap) throws
ParseException
{
//conversion de la date
SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
Date dateCreation = dateformat.parse(String.valueOf(date));
formateur.setDateCreation(dateCreation);

Formateur saveFormateur = formateurService.saveFormateur(formateur);
String msg ="formateur enregistré avec Id "+saveFormateur.getIdFormateur();
modelMap.addAttribute("msg", msg);
return "createFormateur";
}

@RequestMapping("/listeFormateur")

public String listeFormateur(ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
Page<Formateur> f = formateurService.getAllFormateursParPage(page, size);
modelMap.addAttribute("formateurs", f);
 modelMap.addAttribute("pages", new int[f.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
return "listeFormateur";
}



@RequestMapping("/supprimerFormateur")
public String supprimerFormateur(@RequestParam("id") Long id,
ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
	formateurService.deleteFormateurById(id);
Page<Formateur> f = formateurService.getAllFormateursParPage(page,
size);
modelMap.addAttribute("formateurs", f);
modelMap.addAttribute("pages", new int[f.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
modelMap.addAttribute("size", size);
return "listeFormateur";
}

@RequestMapping("/modifierformateur")
public String editerLabo(@RequestParam("id") Long id,ModelMap modelMap)
{
Formateur f= formateurService.getFormateur(id);
modelMap.addAttribute("formateur", f);
return "editFormateur";
}
@RequestMapping("/updateFormateur")
public String updateLabo(@ModelAttribute("formateur") Formateur formateur,
@RequestParam("date") String date,
ModelMap modelMap) throws ParseException
{
//conversion de la date
 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
 Date dateCreation = dateformat.parse(String.valueOf(date));
 formateur.setDateCreation(dateCreation);

 formateurService.updateFormateur(formateur);
 List<Formateur> f = formateurService.getAllFormateurs();
 modelMap.addAttribute("formateurs", f);
return "listeLaboFormateur";
}

}
