package com.ramla.project.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.ramla.project.entities.Labo;

import com.ramla.project.service.LaboService;

@Controller
public class LaboController {
@Autowired
LaboService laboService;



@RequestMapping("/showCreate")
public String showCreate(ModelMap modelMap)
{
	modelMap.addAttribute("labo", new Labo());
return "createLabo";
}


@RequestMapping("/saveLabo")
public String saveLabo(@Valid Labo labo,
		 BindingResult bindingResult)
		{
		if (bindingResult.hasErrors()) return "createLabo";
 laboService.saveLabo(labo);
 return "createLabo";
}
@RequestMapping("/listeLabo")
public String listeLabo(ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
Page<Labo> l = laboService.getAllLabosParPage(page, size);
modelMap.addAttribute("labos", l);
 modelMap.addAttribute("pages", new int[l.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
return "listeLabo";
}





@RequestMapping("/supprimerLabo")
public String supprimerLabo(@RequestParam("id") Long id,
ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
	laboService.deleteLaboById(id);
Page<Labo> l = laboService.getAllLabosParPage(page,
size);
modelMap.addAttribute("labos", l);
modelMap.addAttribute("pages", new int[l.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
modelMap.addAttribute("size", size);
return "listeLabo";
}


@RequestMapping("/modifierLabo")
public String editerLabo(@RequestParam("id") Long id,ModelMap modelMap)
{
Labo l= laboService.getLabo(id);
modelMap.addAttribute("labo", l);
return "editLabo";
}
@RequestMapping("/updateLabo")
public String updateLabo(@ModelAttribute("labo") Labo labo,
@RequestParam("date") String date,
ModelMap modelMap) throws ParseException
{
//conversion de la date
 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
 Date dateCreation = dateformat.parse(String.valueOf(date));
 labo.setDateCreation(dateCreation);

 laboService.updateLabo(labo);
 List<Labo> l = laboService.getAllLabos();
 modelMap.addAttribute("labos", l);
return "listeLabo";
}


}