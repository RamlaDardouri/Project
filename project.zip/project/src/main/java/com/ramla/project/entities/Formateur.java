package com.ramla.project.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Formateur {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idFormateur;
private String nom;
private int cin;
private String type;


private Date dateCreation;

public Formateur() {
super();
}

public Formateur(String nom, int cin, String type, Date dateCreation) {
	super();
	this.nom = nom;
	this.cin = cin;
	this.type = type;
	this.dateCreation = dateCreation;
}

public Long getIdFormateur() {
	return idFormateur;
}

public void setIdFormateur(Long idFormateur) {
	this.idFormateur = idFormateur;
}

public String getNom() {
	return nom;
}

public void setNom(String nom) {
	this.nom = nom;
}

public int getCin() {
	return cin;
}

public void setCin(int cin) {
	this.cin = cin;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public Date getDateCreation() {
	return dateCreation;
}

public void setDateCreation(Date dateCreation) {
	this.dateCreation = dateCreation;
}

@Override
public String toString() {
	return "Formateur [idFormateur=" + idFormateur + ", nom=" + nom + ", cin=" + cin + ", type=" + type
			+ ", dateCreation=" + dateCreation + "]";
}



}
