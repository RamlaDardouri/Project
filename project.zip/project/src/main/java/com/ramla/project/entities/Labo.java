package com.ramla.project.entities;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
public class Labo {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idLabo;
@Size (min = 1,max = 15)
private int nbr;
@Size (min = 4,max = 15)
private String description;
@Size (min = 4,max = 15)
private String type;
@Temporal(TemporalType.DATE)
@DateTimeFormat(pattern = "yyyy-MM-dd")
@PastOrPresent
private Date dateCreation;



public Labo() {
super();
}

public Labo(int nbr, String description, String type, Date dateCreation) {
	super();
	this.nbr = nbr;
	this.description = description;
	this.type = type;
	this.dateCreation = dateCreation;
}

public Long getIdLabo() {
	return idLabo;
}

public void setIdLabo(Long idLabo) {
	this.idLabo = idLabo;
}

public int getNbr() {
	return nbr;
}

public void setNbr(int nbr) {
	this.nbr = nbr;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public Date getDateCreation() {
	return dateCreation;
}

public void setDateCreation(Date dateCreation) {
	this.dateCreation = dateCreation;
}

@Override
public String toString() {
	return "Labo [idLabo=" + idLabo + ", nbr=" + nbr + ", description=" + description + ", type=" + type
			+ ", dateCreation=" + dateCreation + "]";
}




}